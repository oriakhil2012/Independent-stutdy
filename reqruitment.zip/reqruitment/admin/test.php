
<?php 
	$file = fopen("countries.txt", "r") or die("Unable to open");
		$myfile =  fgets($file);
			foreach (explode(";", $myfile) as $product) {
				echo $product. "<br>";
				}
			fclose($file);
						
?>