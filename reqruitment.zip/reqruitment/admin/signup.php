<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Admin | Recruitment Management System</title>
 	

<?php
	 include('./header.php'); 
 // include('./auth.php'); 
 ?>

</head>
<style>
	.logo {
    margin: auto;
    font-size: 20px;
    background: white;
    padding: 7px 11px;
    border-radius: 50% 50%;
    color: #000000b3;
}
</style>

<nav class="navbar navbar-light fixed-top bg-primary" style="padding:0;">
  <div class="container-fluid mt-2 mb-2">
  	<div class="col-lg-12">
  		<div class="col-md-1 float-left" style="display: flex;">
  			<div class="logo">
  				<span class="fa fa-hands-helping"></span>
  			</div>
  		</div>
      <div class="col-md-4 float-left text-white"> <center>
        <large><b>Sign Up for Recruitment Management System</b></large></center>
      </div>
	  	<div class="col-md-2 float-right text-white">
	  		<a href="ajax.php?action=logout" class="text-white">Please Sign Up<i class="fa fa-power-off"></i></a>
	    </div>
    </div>
  </div>
</nav>

<nav id="sidebar" class='mx-lt-5 bg-dark' >
		
		<div class="sidebar-list">
	
			
		</div>

</nav>
<style>
	#login-right{
		margin-top: 100px;
		/* margin-left: */
	}
</style>
<center>
<main id="main">
  		<div id="login-left">
  			
  		</div>

  		<div id="login-right">
  			<div class="card col-md-6">
  				<div class="card-body">
  						<div class="logo">
			  				<span class="fa fa-hands-helping"></span>
			  			</div>
  					<form id="login-form" >
  						<div class="form-group">
  							<!-- <label for="username" class="control-label">Username</label> -->
  							<input type="text" id="name" name="name" class="form-control col-md-6" placeholder="Enter your Name">
  						</div>
  						<div class="form-group">
  							
  							<input type="text" id="email" name="email" class="form-control  col-md-6" placeholder="Enter Email">
  						</div>
						  <div class="form-group">
  							<input type="password" id="password" name="password" class="form-control  col-md-6" placeholder="Enter your password">
  						</div>
						  <div class="form-group">
  							<input type="text" id="contact" name="contact" class="form-control  col-md-6" placeholder="Enter Contact Number">
  						</div>
						  <div class="form-group">
  							<input type="text" id="address" name="address" class="form-control  col-md-6" placeholder="Enter Address">
  						</div>
  						<center><button class="btn-sm btn-block btn-wave col-md-4 btn-primary" name="signup">Sign UP</button>	</center>
  					</form>
					  
  				</div>
  			</div>
  		</div>
   			

  </main>
  </center>


<script>
	$('#login-form').submit(function(e){
		e.preventDefault()
		$('#login-form button[name="signup"]').attr('disabled',true).html('Sign Up...');
		if($(this).find('.alert-danger').length > 0 )
			$(this).find('.alert-danger').remove();
		$.ajax({
			url:'ajax.php?action=signup',
			method:'POST',
			data:$(this).serialize(),
			error:err=>{
				console.log(err)
		$('#login-form button[type="button"]').removeAttr('disabled').html('Login');

			},
			success:function(resp){
				
				if(resp == 1){
					location.href ='index.php?page=applications';
					
				}else if(resp == 2){
					$('#login-form').prepend('<div class="alert alert-danger">Email is already Exist.</div>')
					$('#login-form button[type="button"]').removeAttr('disabled').html('Login');
				}else{
					$('#login-form').prepend('<div class="alert alert-danger">User is not added in Database.</div>')
					$('#login-form button[type="button"]').removeAttr('disabled').html('Login');
				}
			}
		})
	})
</script>	