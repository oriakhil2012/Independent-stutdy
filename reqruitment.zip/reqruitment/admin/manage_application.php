
<?php include 'db_connect.php' ?>

<?php
	if(isset($_GET['id'])){
		$application = $conn->query("SELECT  a.*,v.position FROM application a inner join vacancy v on v.id = a.position_id where a.id=".$_GET['id'])->fetch_array();
		foreach($application as $k => $v){
			$$k = $v;
		}
		  $fname = explode('_',$resume_path);
	       unset($fname[0]);
	       $fname = implode("",$fname);
	}
	$qry = $conn->query("SELECT * FROM vacancy ");
	while($row=$qry->fetch_assoc()){
		$pos[$row['id']] = $row['position'];
	}
	$rs = $conn->query("SELECT * FROM recruitment_status ");
	while($row=$rs->fetch_assoc()){
		$stat[$row['id']] = $row['status_label'];
	}

	
?>

<body>
	
</body>
</html>
<div class="container-fluid">
<b>Personal Information </b><br>
	<form id="manage-application">
		<input type="hidden" name="id" value="<?php echo isset($id)? $id : '' ?>">
	<div class="col-md-12">
		<div class="row form-group">
			<div class="col-md-6">
				<label for="" class="control-label">Position</label>
				<select class="custom-select browser-default select2" name="position_id">
					<option value=""></option>
					<?php foreach($pos as $k => $v): ?>
						<option value="<?php echo $k ?>" <?php echo isset($position_id) && $position_id == $k ? "selected" : '' ?>><?php echo $v ?></option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>
		<div class="row form-group">
			<div class="col-md-4">
				<label for="" class="control-label">Last Name</label>
				<input type="text" class="form-control" name="lastname" required="" value="<?php echo isset($lastname) ? $lastname:''  ?>">
			</div>
			<div class="col-md-4">
				<label for="" class="control-label">First Name</label>
				<input type="text" class="form-control" name="firstname" required="" value="<?php echo isset($firstname) ? $firstname:''  ?>">
			</div>
			<div class="col-md-4">
				<label for="" class="control-label">Middle Name</label>
				<input type="text" class="form-control" name="middlename" required="" value="<?php echo isset($middlename) ? $middlename:''  ?>">
			</div>
		</div>
		<div class="row form-group">
			<div class="col-md-4">
				<label for="" class="control-label">Gender</label>
				<select name="gender" id="" class="custom-select browser-default">
					<option <?php echo isset($gender) && $gender == 'Male' ? "selected" : '' ?>>Male</option>
					<option <?php echo isset($gender) && $gender == 'Female' ? "selected" : '' ?>>Female</option>
				</select>
			</div>
			<div class="col-md-4">
				<label for="" class="control-label">Email</label>
				<input type="email" class="form-control" name="email" required="" value="<?php echo isset($email) ? $email:''  ?>">
			</div>
			<div class="col-md-4">
				<label for="" class="control-label">Contact</label>
				<input type="text" class="form-control" name="contact" required="" value="<?php echo isset($contact) ? $contact:''  ?>">
			</div>
					</div>
		<div class="row form-group">
			<div class="col-md-3">
				<label for="position_id" class="control-label">Age</label>
				<select class="custom-select browser-default select2" name="age_id">
				<option value=""></option>
					<?php for($x = 18; $x<=60; $x++){ ?>
						<option value="<?php echo $x; ?>"> <?php echo $x; ?> </option>
					<?php } ?>		
				</select>
			</div>
			<div class="col-md-3">	
				<label for="countries">Your Country:</label>
				<select class="custom-select browser-default select2" name="country_id">
				<option value=""></option>
				<?php 
					$file = fopen("countries.txt", "r") or die("Unable to open");
					$myfile =  fgets($file);
				 		foreach (explode(";", $myfile) as $country){?>
						<option value="<?php echo $country; ?>"> <?php echo $country; ?> </option>
					<?php } fclose($file); ?>		
				</select>
			</div>
			<select class="selectpicker countrypicker" data-live-search="true" 	 data-default="United States">
			</select>
			<div class="col-md-3">
				<label for="position_id" class="control-label">Teaching Certification</label>
				<select class="custom-select browser-default select2" name="position_id">
					<option value=""></option>
						<option value="N/A"  "selected">N/A</option>
						<option value="TEFL">TEFL</option>
						<option value="TESOL">TESOL</option>
						<option value="TESL" >TESL</option>
						<option value="CELTA" >CELTA</option>
						<option value="DELTA" >DELTA</option>
				</select>
			</div>
			<div class="col-md-3">
				<label for="position_id" class="control-label">Eng Proficiency</label>
				<select class="custom-select browser-default select2" name="position_id">
					<option value=""></option>
						<option value="TOEFL(CB)"  "selected">TOEFL(CB)</option>
						<option value="TOEFL(PB)">TOEFL(PB)</option>
						<option value="IELTS">IELTS</option>
						<option TOEIC="TESL" >TOEIC</option>
						<option value="OPI" >OPI</option>
						<option value="OPIC" >OPIC</option>
				</select>
			</div>
		</div>
		<div class="row form-group">
			<div class="col-md-3 ">
				<label for="" class="control-label">Score</label>
				<input type="number" class="form-control" name="score" required="" value="<?php echo isset($score) ? $middlename:''  ?>">
			</div>
			<div class="col-md-3 ">
				<label for="" class="control-label">Race</label>
				<input type="text" class="form-control" name="Race" required="" value="<?php echo isset($Race) ? $middlename:''  ?>">
			</div>
			<div class="col-md-3 ">
				<label for="" class="control-label">Ethnic</label>
				<input type="text" class="form-control" name="Ethnic" required="" value="<?php echo isset($Ethnic) ? $middlename:''  ?>">
			</div>
			<div class="col-md-3 ">
				<label for="" class="control-label">Accent</label>
				<input type="text" class="form-control" name="Accent" required="" value="<?php echo isset($Accent) ? $middlename:''  ?>">
			</div>
			
		</div>

			<div class="row form-group">
			<div class="col-md-3 ">
				<label for="" class="control-label">ID/Passport No.</label>
				<input type="number" class="form-control" name="ID/Passport No." required="" value="<?php echo isset($score) ? $middlename:''  ?>">
			</div>
			<div class="col-md-3">
				<div class="dropdown">
   					<label>Expiry Date: </label>
        				<input type="date" class="form-control">
					</div>
				</select>
			</div>
			<div class="col-md-3 ">
				<label for="" class="control-label">Type of Visa</label>
				<input type="text" class="form-control" name="Type of Visa" required="" value="<?php echo isset($Ethnic) ? $middlename:''  ?>">
			</div>
			<div class="col-md-3">
				<div class="dropdown">
   					<label>Valid Until: </label>
        				<input type="date" class="form-control">
					</div>
				</select>
			</div>
			
		</div>
		
			<div class="form-check">
  				<input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
  					<label class="form-check-label" for="flexRadioDefault1">NES</label>
			</div>
			<div class="form-check">
  				<input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
  					<label class="form-check-label" for="flexRadioDefault1">NON-NES</label>
			</div>
	
		
		<hr><b>EDUCATION </b><br><br>
		<div class="row form-group">
			<div class="col-md-3">
				<label for="position_id" class="control-label">Degree</label>
				<select class="custom-select browser-default select2" name="position_id">
					<option value=""></option>
						<option value="High School"  "selected">High School</option>
						<option value="Diploma">Diploma</option>
						<option value="Bachelor" >Bachelor</option>
						<option value="Master" >Master</option>
				</select>
			</div>
			<div class="col-md-3">
				<label for="" class="control-label">Major</label>
				<input type="text" class="form-control" name="major" required="" value="">
			</div>
			<div class="col-md-3">
				<label for="" class="control-label">Institution</label>
				<input type="text" class="form-control" name="Institution" required="" value="">
			</div>
			<div class="col-md-3">
				<div class="dropdown">
   					<label>Graduated: </label>
        				<input type="date" class="form-control">
					</div>
				</select>
			</div>
		</div>
		<hr><b>EXPERIENCE </b><br><br>
		<div class="row form-group">
			<div class="col-md-3">
				<label for="" class="control-label">Organization</label>
				<input type="text" class="form-control" name="Organization" required="" value="">
			</div>
			<div class="col-md-3">
				<label for="" class="control-label">Position</label>
				<input type="text" class="form-control" name="Position" required="" value="">
			</div>
			<div class="col-md-3">
				<div class="dropdown">
   					<label>From: </label>
        				<input type="date" class="form-control">
					</div>
				</select>
			</div>
			<div class="col-md-3">
				<div class="dropdown">
   					<label>To: </label>
        				<input type="date" class="form-control">
					</div>
				</select>
			</div>
		</div>
		<div class="row form-group">
			<div class="col-md-10">
				<label for="" class="control-label">Cover Letter</label>
				<textarea name="cover_letter" id="" cols="30" rows="3" placeholder="(Optional)" class="form-control"><?php echo isset($cover_letter) ? $cover_letter:''  ?></textarea>
			</div>
		</div>
		<div class="row form-group">
			<div class="input-group col-md-10 mb-3">
				<div class="input-group-prepend">
			    <span class="input-group-text" id="">Resume</span>
			  </div>
			  <div class="custom-file">
			    <input type="file" class="custom-file-input" id="resume" onchange="displayfname(this,$(this))" name="resume" accept="application/msword,text/plain, application/pdf">
			    <label class="custom-file-label" for="resume"><?php echo isset($fname) ? $fname:'Choose file'  ?></label>
			  </div>
			  
			</div>
		</div>
		<?php if(isset($id)): ?>
		<div class="row form-group">
			<div class="col-md-6">
				<label for="" class="control-label">Status</label>
				<select class="custom-select browser-default select2" name="status">
					<option value="0" <?php echo isset($process_id) && $process_id == 0? "selected" : '' ?>>New</option>
					<?php foreach($stat as $k => $v): ?>
						<option value="<?php echo $k ?>" <?php echo isset($process_id) && $process_id == $k ? "selected" : '' ?>><?php echo $v ?></option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>
		<?php endif; ?>
	</div>
	</form>
</div>

<script>
	function displayfname(input,_this) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
        	console.log(input.files[0].name)
        	_this.siblings('label').html(input.files[0].name);
        }

        reader.readAsDataURL(input.files[0]);
    }
}
$(document).ready(function(){
	$('.select2').select2({
		width:"100%",
		placeholder:'Please select here'
	})
	$('#manage-application').submit(function(e){
		e.preventDefault()
		start_load()
		$.ajax({
			url:'ajax.php?action=save_application',
			data: new FormData($(this)[0]),
		    cache: false,
		    contentType: false,
		    processData: false,
		    method: 'POST',
		    type: 'POST',
			error:err=>{
				console.log(err)
			},
			success:function(resp){
				if(resp == 1){
					alert_toast('Application successfully submitted.','success')
					setTimeout(function(){
						location.reload()
					},1000)
				}
			}
		})

	})
})
</script>
